clear all;
close all;
R1 = 4;
R2 = 2;
R3 = 3;
L = 1.6;
C = 0.25;