% Magnetic manipulation
clear all
%close all
clc

figure(1)
hold on

% Variables
g = 9.81; % m/s2
gamma = 72e-3; % N/m
phi = 7.2e-4; % rad
rho = 8902; % kg/m3
V = 100e-6*90e-6*25e-6; % m3
I = 0.2; % A
h = 3.39e-7; % kg/s
k = 3750; % T/Am2
Rc = 400e-6; % m
m = rho*V;

timeSpan = 0:1e-6:100e-3;
initCond = 0;
options = odeset('RelTol',1e-4,'AbsTol',1e-6);

[t,x] = ode45(@(t,x) odefun(t,x,m,g,Rc,k,V,I,h),timeSpan, initCond, options);

plot(t,x);

function dxdt = odefun(t,x,m,g,Rc,k,V,I,h)
dxdt = (-m*g/Rc*x + k*V*I^2)/h;
end

