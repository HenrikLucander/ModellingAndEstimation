% Chemical reactor
clear all
close all
clc

% Variables
V = 10;
q = 0.25;
k = 9.4*exp(-2500/(8.31*293));

A = [ -(q/V + k) 0 ; k -q/V];
B = [q/V ; 0];
C = [0 1];
D = 0;

u = @(t) 1/(1/3*sqrt(pi)).*exp(-(t/(1/3)).^2) ;
timeSpan = 0:0.01:200;
initCond = [0 0]';

% With transfert function
sys = ss(A,B,C,D);
[num,den] = ss2tf(A,B,C,D,1);
H = tf(num,den);

lsim(H,u(timeSpan),timeSpan);
ylim([0 12e-3])
hold on;

% With state space model
system = @(t,x) A*x + B*u(t);
output = @(t,x) C*x + D*u(t);

options = odeset('RelTol',1e-4,'AbsTol',1e-6);
[T1,X1] = ode45(system, timeSpan, initCond, options);
Y1 = output(T1',X1');

figure(1)
hold on;
plot(T1,X1(:,1));
plot(T1,Y1);
xlabel('Time (s)')
ylabel('Concentration (mol/L)');